%  for i=1:(length(A_karate)/2)
%     Th_karate0101(:,i)=THREE5(A_karate,CN,s,0.5,0.5,i,D);
%     %����34*(length(A_karate)/2)  �õ��ľ������ֱ�������ŵ�kend������
%  end

%  for i=1:(length(A_dolphins)/2)
%     Th_dolphins0101(:,i)=get_THREE4(A_dolphins,CN,s,0.5,0.5,i,D);
%     %����34*(length(A_karate)/2)  �õ��ľ������ֱ�������ŵ�kend������
%  end

% 
%  for i=1:(length(A_Polbooks)/2)
%     Th_polbooks0101(:,i)=THREE5(A_Polbooks,CN,s,0.5,0.5,i,D);
%     %����34*(length(A_karate)/2)  �õ��ľ������ֱ�������ŵ�kend������
%  end

% for i=1:(length(A_Jazz)/2)
%     Th_jazz0101(:,i)=THREE5(A_Jazz,CN,s,0.5,0.5,i,D);
%     %����34*(length(A_karate)/2)  �õ��ľ������ֱ�������ŵ�kend������
%  end

% for i=1:(length(A_USAir)/2)
%     Th_usair0101(:,i)=THREE5(A_USAir,CN,s,0.5,0.5,i,D);
%     %����34*(length(A_karate)/2)  �õ��ľ������ֱ�������ŵ�kend������
%  end

% for i=1:(length(ns379)/2)
%     Th_ns3790101(:,i)=get_THREE4(ns379,CN,s,0.5,0.5,i,D);
%     %����34*(length(A_karate)/2)  �õ��ľ������ֱ�������ŵ�kend������
%  end

for i=1:(length(A_EEC)/2)
    Th_eec0101(:,i)=THREE5(A_EEC,CN,s,0.5,0.5,i,D);
    %����34*(length(A_karate)/2)  �õ��ľ������ֱ�������ŵ�kend������
 end

% for i=1:(length(A_Email)/2)
%     Th_email0101(:,i)=get_THREE4(A_Email,CN,s,0.5,0.5,i,D);
%     %����34*(length(A_karate)/2)  �õ��ľ������ֱ�������ŵ�kend������
%  end

% for i=1:(length(A_Neural)/2)
%     Th_neural0101(:,i)=THREE5(A_Neural,CN,s,0.5,0.5,i,D);
%     %����34*(length(A_karate)/2)  �õ��ľ������ֱ�������ŵ�kend������
%  end

% for i=1:(length(A_Polblogs)/2)
%     Th_polblogs0101(:,i)=get_THREE4(A_Polblogs,CN,s,0.5,0.5,i,D);
%     %����34*(length(A_karate)/2)  �õ��ľ������ֱ�������ŵ�kend������
%  end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% K2=13;  
% for i=1:11
%     theta=(i-1)/10;
%     for j=1:11
%         alpha=(j-1)/10;
%         %Th_Yeast(i,j)={Three(A_Yeast,T1_Yeast_gy,Tg_Yeast101,theta,alpha,K2)};
%         %Th_karate(i,j)={THREE2(A_karate,CN,s,theta,alpha,theta,K2)};
%         Th_karate(i,j)={THREE5(A_karate,CN,s,theta,alpha,K2,D)};
%         %Th_karate(i,j)={TWO(A_karate,CN,T1_Karate_gy,theta,alpha,theta,K2)};
%     end
% end

% K2=3;  
% for i=1:11
%     theta=(i-1)/10;
%     for j=1:11
%         alpha=(j-1)/10;
%         %Th_Yeast(i,j)={Three(A_Yeast,T1_Yeast_gy,Tg_Yeast101,theta,alpha,K2)};
%         %Th_karate(i,j)={THREE2(A_karate,CN,s,theta,alpha,theta,K2)};
%         Th_dolphins(i,j)={get_THREE4(A_dolphins,CN,s,theta,alpha,K2,D)};
%         %Th_karate(i,j)={TWO(A_karate,CN,T1_Karate_gy,theta,alpha,theta,K2)};
%     end
% end
 
% K2=46;  
% for i=1:11
%     theta=(i-1)/10;
%     for j=1:11
%         alpha=(j-1)/10;
%         %Th_Yeast(i,j)={Three(A_Yeast,T1_Yeast_gy,Tg_Yeast101,theta,alpha,K2)};
%         %Th_karate(i,j)={THREE2(A_karate,CN,s,theta,alpha,theta,K2)};
%         Th_polbooks(i,j)={THREE5(A_Polbooks,CN,s,theta,alpha,K2,D)};
%         %Th_karate(i,j)={TWO(A_karate,CN,T1_Karate_gy,theta,alpha,theta,K2)};
%     end
% end

% K2=85;  
% for i=1:11
%     theta=(i-1)/10;
%     for j=1:11
%         alpha=(j-1)/10;
%         %Th_Yeast(i,j)={Three(A_Yeast,T1_Yeast_gy,Tg_Yeast101,theta,alpha,K2)};
%         %Th_karate(i,j)={THREE2(A_karate,CN,s,theta,alpha,theta,K2)};
%         Th_Jazz(i,j)={THREE5(A_Jazz,CN,s,theta,alpha,K2,D)};
%         %Th_karate(i,j)={TWO(A_karate,CN,T1_Karate_gy,theta,alpha,theta,K2)};
%     end
% end

% K2=165;  
% for i=1:11
%     theta=(i-1)/10;
%     for j=1:11
%         alpha=(j-1)/10;
%         %Th_Yeast(i,j)={Three(A_Yeast,T1_Yeast_gy,Tg_Yeast101,theta,alpha,K2)};
%         %Th_karate(i,j)={THREE2(A_karate,CN,s,theta,alpha,theta,K2)};
%         Th_USAir(i,j)={THREE5(A_USAir,CN,s,theta,alpha,K2,D)};
%         %Th_karate(i,j)={TWO(A_karate,CN,T1_Karate_gy,theta,alpha,theta,K2)};
%     end
% end

% K2=566;  
% for i=1:11
%     theta=(i-1)/10;
%     for j=1:11
%         alpha=(j-1)/10;
%         %Th_Yeast(i,j)={Three(A_Yeast,T1_Yeast_gy,Tg_Yeast101,theta,alpha,K2)};
%         %Th_karate(i,j)={THREE2(A_karate,CN,s,theta,alpha,theta,K2)};
%         Th_email(i,j)={THREE5(A_Email,CN,s,theta,alpha,K2,D)};
%         %Th_karate(i,j)={TWO(A_karate,CN,T1_Karate_gy,theta,alpha,theta,K2)};
%     end
% end

% K2=14;  
% for i=1:11
%     theta=(i-1)/10;
%     for j=1:11
%         alpha=(j-1)/10;
%         %Th_Yeast(i,j)={Three(A_Yeast,T1_Yeast_gy,Tg_Yeast101,theta,alpha,K2)};
%         %Th_karate(i,j)={THREE2(A_karate,CN,s,theta,alpha,theta,K2)};
%         Th_netscience(i,j)={get_THREE4(ns379,CN,s,theta,alpha,K2,D)};
%         %Th_karate(i,j)={TWO(A_karate,CN,T1_Karate_gy,theta,alpha,theta,K2)};
%     end
%  end

% K2=3;  
% for i=1:11
%     theta=(i-1)/10;
%     for j=1:11
%         alpha=(j-1)/10;
%         %Th_Yeast(i,j)={Three(A_Yeast,T1_Yeast_gy,Tg_Yeast101,theta,alpha,K2)};
%         %Th_karate(i,j)={THREE2(A_karate,CN,s,theta,alpha,theta,K2)};
%         Th_dolphins(i,j)={get_THREE4(A_dolphins,CN,s,theta,alpha,K2,D)};
%         %Th_karate(i,j)={TWO(A_karate,CN,T1_Karate_gy,theta,alpha,theta,K2)};
%     end
% end

% K2=87;  
% for i=1:11
%     theta=(i-1)/10;
%     for j=1:11
%         alpha=(j-1)/10;
%         %Th_Yeast(i,j)={Three(A_Yeast,T1_Yeast_gy,Tg_Yeast101,theta,alpha,K2)};
%         %Th_karate(i,j)={THREE2(A_karate,CN,s,theta,alpha,theta,K2)};
%         Th_neural(i,j)={THREE5(A_Neural,CN,s,theta,alpha,K2,D)};
%         %Th_karate(i,j)={TWO(A_karate,CN,T1_Karate_gy,theta,alpha,theta,K2)};
%     end
% end