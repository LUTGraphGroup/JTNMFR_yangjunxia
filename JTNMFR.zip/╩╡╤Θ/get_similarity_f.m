function s=get_similarity_f(A)
s=zeros(length(A));
d=sum(A);
for i=1:length(A)
    Ni=find(A(i,:)==1);
    for j=1:length(A)
        if d(i)==0
            s(i,i)=1;
        else
            Nj=find(A(j,:)==1);
            s(i,j)=length(intersect(Ni,Nj))/length(union(Ni,Nj));
        end
    end
end
end